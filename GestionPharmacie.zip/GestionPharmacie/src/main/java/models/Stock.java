package models;

import java.util.Date;

public class Stock {
    private int id;
    private int medicamentId;
    private String medicamentNom;
    private int quantite;
    private String lot;
    private Date dateFabrication;
    private Date dateExpiration;
    private Date dateEntree;
    
    public Stock() {}
    
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getMedicamentId() { return medicamentId; }
    public void setMedicamentId(int medicamentId) { this.medicamentId = medicamentId; }
    public String getMedicamentNom() { return medicamentNom; }
    public void setMedicamentNom(String medicamentNom) { this.medicamentNom = medicamentNom; }
    public int getQuantite() { return quantite; }
    public void setQuantite(int quantite) { this.quantite = quantite; }
    public String getLot() { return lot; }
    public void setLot(String lot) { this.lot = lot; }
    public Date getDateFabrication() { return dateFabrication; }
    public void setDateFabrication(Date dateFabrication) { this.dateFabrication = dateFabrication; }
    public Date getDateExpiration() { return dateExpiration; }
    public void setDateExpiration(Date dateExpiration) { this.dateExpiration = dateExpiration; }
    public Date getDateEntree() { return dateEntree; }
    public void setDateEntree(Date dateEntree) { this.dateEntree = dateEntree; }
}