package dao;

import models.Medicament;
import utils.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MedicamentDAO {
    
    public List<Medicament> getAllMedicaments() {
        List<Medicament> medicaments = new ArrayList<>();
        String sql = "SELECT m.*, f.nom as fournisseur_nom, COALESCE(SUM(s.quantite), 0) as stock_actuel " +
                     "FROM medicaments m " +
                     "LEFT JOIN fournisseurs f ON m.fournisseur_id = f.id " +
                     "LEFT JOIN stocks s ON m.id = s.medicament_id " +
                     "GROUP BY m.id ORDER BY m.id";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Medicament m = new Medicament();
                m.setId(rs.getInt("id"));
                m.setCode(rs.getString("code"));
                m.setNom(rs.getString("nom"));
                m.setDescription(rs.getString("description"));
                m.setDosage(rs.getString("dosage"));
                m.setForme(rs.getString("forme"));
                m.setPrixUnitaire(rs.getBigDecimal("prix_unitaire"));
                m.setFournisseurId(rs.getInt("fournisseur_id"));
                m.setFournisseurNom(rs.getString("fournisseur_nom"));
                m.setSeuilAlerte(rs.getInt("seuil_alerte"));
                m.setStockActuel(rs.getInt("stock_actuel"));
                medicaments.add(m);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return medicaments;
    }
    
    public Medicament getMedicamentById(int id) {
        String sql = "SELECT m.*, f.nom as fournisseur_nom FROM medicaments m " +
                     "LEFT JOIN fournisseurs f ON m.fournisseur_id = f.id WHERE m.id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                Medicament m = new Medicament();
                m.setId(rs.getInt("id"));
                m.setCode(rs.getString("code"));
                m.setNom(rs.getString("nom"));
                m.setDescription(rs.getString("description"));
                m.setDosage(rs.getString("dosage"));
                m.setForme(rs.getString("forme"));
                m.setPrixUnitaire(rs.getBigDecimal("prix_unitaire"));
                m.setFournisseurId(rs.getInt("fournisseur_id"));
                m.setFournisseurNom(rs.getString("fournisseur_nom"));
                m.setSeuilAlerte(rs.getInt("seuil_alerte"));
                return m;
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }
    
    public boolean addMedicament(Medicament m) {
        String sql = "INSERT INTO medicaments (code, nom, description, dosage, forme, prix_unitaire, fournisseur_id, seuil_alerte) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, m.getCode());
            pstmt.setString(2, m.getNom());
            pstmt.setString(3, m.getDescription());
            pstmt.setString(4, m.getDosage());
            pstmt.setString(5, m.getForme());
            pstmt.setBigDecimal(6, m.getPrixUnitaire());
            pstmt.setInt(7, m.getFournisseurId());
            pstmt.setInt(8, m.getSeuilAlerte());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }
    
    public boolean updateMedicament(Medicament m) {
        String sql = "UPDATE medicaments SET code=?, nom=?, description=?, dosage=?, forme=?, prix_unitaire=?, fournisseur_id=?, seuil_alerte=? WHERE id=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, m.getCode());
            pstmt.setString(2, m.getNom());
            pstmt.setString(3, m.getDescription());
            pstmt.setString(4, m.getDosage());
            pstmt.setString(5, m.getForme());
            pstmt.setBigDecimal(6, m.getPrixUnitaire());
            pstmt.setInt(7, m.getFournisseurId());
            pstmt.setInt(8, m.getSeuilAlerte());
            pstmt.setInt(9, m.getId());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }
    
    public boolean deleteMedicament(int id) {
        String sql = "DELETE FROM medicaments WHERE id=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }
    
    public int count() {
        String sql = "SELECT COUNT(*) FROM medicaments";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }
}