package dao;

import utils.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import models.Stock;

public class StockDAO {
    
    public List<Stock> getAllStocks() {
        List<Stock> stocks = new ArrayList<>();
        String sql = "SELECT s.*, m.nom as medicament_nom FROM stocks s " +
                     "JOIN medicaments m ON s.medicament_id = m.id ORDER BY s.date_expiration ASC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Stock stock = new Stock();
                stock.setId(rs.getInt("id"));
                stock.setMedicamentId(rs.getInt("medicament_id"));
                stock.setMedicamentNom(rs.getString("medicament_nom"));
                stock.setQuantite(rs.getInt("quantite"));
                stock.setLot(rs.getString("lot"));
                stock.setDateFabrication(rs.getDate("date_fabrication"));
                stock.setDateExpiration(rs.getDate("date_expiration"));
                stock.setDateEntree(rs.getTimestamp("date_entree"));
                stocks.add(stock);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return stocks;
    }
    
    public boolean addStock(int medicamentId, int quantite, String lot, Date dateExpiration) {
        String sql = "INSERT INTO stocks (medicament_id, quantite, lot, date_expiration) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, medicamentId);
            pstmt.setInt(2, quantite);
            pstmt.setString(3, lot);
            pstmt.setDate(4, dateExpiration);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public int countExpirationProche(int jours) {
        String sql = "SELECT COUNT(*) FROM stocks WHERE date_expiration <= DATE_ADD(CURDATE(), INTERVAL ? DAY) AND quantite > 0";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, jours);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }
}