package dao;

import models.Fournisseur;
import utils.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FournisseurDAO {
    
    public List<Fournisseur> getAllFournisseurs() {
        List<Fournisseur> fournisseurs = new ArrayList<>();
        String sql = "SELECT * FROM fournisseurs ORDER BY nom";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Fournisseur f = new Fournisseur();
                f.setId(rs.getInt("id"));
                f.setNom(rs.getString("nom"));
                f.setContact(rs.getString("contact"));
                f.setTelephone(rs.getString("telephone"));
                f.setEmail(rs.getString("email"));
                f.setAdresse(rs.getString("adresse"));
                fournisseurs.add(f);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return fournisseurs;
    }
    
    public int count() {
        String sql = "SELECT COUNT(*) FROM fournisseurs";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }
    public boolean addFournisseur(Fournisseur f) {
        String sql = "INSERT INTO fournisseurs (nom, contact, telephone, email, adresse) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, f.getNom());
            pstmt.setString(2, f.getContact());
            pstmt.setString(3, f.getTelephone());
            pstmt.setString(4, f.getEmail());
            pstmt.setString(5, f.getAdresse());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }
}