package servlets;

import dao.StockDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.time.LocalDate;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/commander")
public class CommanderServlet extends HttpServlet {
    private StockDAO stockDAO = new StockDAO();
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        int medicamentId = Integer.parseInt(request.getParameter("id"));
        String medicamentNom = request.getParameter("nom");
        
        // Ajouter 100 unités en stock automatiquement
        int quantite = 100;
        String lot = "CMD-" + System.currentTimeMillis();
        Date dateExpiration = Date.valueOf(LocalDate.now().plusYears(2));
        
        boolean success = stockDAO.addStock(medicamentId, quantite, lot, dateExpiration);
        
        // Afficher la page de confirmation
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        out.println("<!DOCTYPE html>");
        out.println("<html><head><title>Commande envoyée</title>");
        out.println("<style>");
        out.println("body { font-family: Arial; display: flex; justify-content: center; align-items: center; height: 100vh; background: linear-gradient(135deg, #00b894, #00cec9); margin: 0; }");
        out.println(".card { background: white; border-radius: 20px; padding: 40px; text-align: center; max-width: 500px; box-shadow: 0 10px 30px rgba(0,0,0,0.2); }");
        out.println(".btn { background: #00b894; color: white; padding: 10px 20px; border: none; border-radius: 10px; cursor: pointer; text-decoration: none; display: inline-block; margin-top: 20px; }");
        out.println(".btn:hover { background: #019874; }");
        out.println("</style>");
        out.println("</head><body>");
        out.println("<div class='card'>");
        
        if (success) {
            out.println("<i class='fas fa-check-circle' style='font-size: 4rem; color: #00b894;'></i>");
            out.println("<h2>✅ Commande envoyée avec succès !</h2>");
            out.println("<p>Une commande de <strong>" + quantite + " unités</strong> pour <strong>" + medicamentNom + "</strong> a été passée.</p>");
            out.println("<p>Lot: <strong>" + lot + "</strong></p>");
            out.println("<p>Date d'expiration: <strong>" + dateExpiration + "</strong></p>");
        } else {
            out.println("<i class='fas fa-exclamation-triangle' style='font-size: 4rem; color: #e74c3c;'></i>");
            out.println("<h2>❌ Erreur lors de la commande</h2>");
            out.println("<p>Veuillez réessayer ultérieurement.</p>");
        }
        
        out.println("<a href='dashboard' class='btn'>Retour au Dashboard</a>");
        out.println("</div>");
        out.println("<script src='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js'></script>");
        out.println("</body></html>");
    }
}