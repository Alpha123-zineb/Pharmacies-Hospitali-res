package servlets;

import dao.MedicamentDAO;
import models.Medicament;
import java.io.IOException;
import java.math.BigDecimal;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/modifier")
public class ModifierMedicamentServlet extends HttpServlet {
    private MedicamentDAO medicamentDAO = new MedicamentDAO();
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        int id = Integer.parseInt(request.getParameter("id"));
        Medicament medicament = medicamentDAO.getMedicamentById(id);
        request.setAttribute("medicament", medicament);
        request.setAttribute("page", "medicaments");
        request.setAttribute("pageTitle", "Modifier médicament");
        request.getRequestDispatcher("/WEB-INF/views/modifierMedicament.jsp").forward(request, response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        int id = Integer.parseInt(request.getParameter("id"));
        String code = request.getParameter("code");
        String nom = request.getParameter("nom");
        String description = request.getParameter("description");
        String dosage = request.getParameter("dosage");
        String forme = request.getParameter("forme");
        BigDecimal prixUnitaire = new BigDecimal(request.getParameter("prixUnitaire"));
        int fournisseurId = Integer.parseInt(request.getParameter("fournisseurId"));
        int seuilAlerte = Integer.parseInt(request.getParameter("seuilAlerte"));
        
        Medicament m = new Medicament();
        m.setId(id);
        m.setCode(code);
        m.setNom(nom);
        m.setDescription(description);
        m.setDosage(dosage);
        m.setForme(forme);
        m.setPrixUnitaire(prixUnitaire);
        m.setFournisseurId(fournisseurId);
        m.setSeuilAlerte(seuilAlerte);
        
        medicamentDAO.updateMedicament(m);
        response.sendRedirect("medicaments");
    }
}