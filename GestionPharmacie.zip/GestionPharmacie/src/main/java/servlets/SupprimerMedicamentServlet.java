package servlets;

import dao.MedicamentDAO;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/supprimer")
public class SupprimerMedicamentServlet extends HttpServlet {
    private MedicamentDAO medicamentDAO = new MedicamentDAO();
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        int id = Integer.parseInt(request.getParameter("id"));
        medicamentDAO.deleteMedicament(id);
        response.sendRedirect("medicaments");
    }
}