package servlets;

import dao.MedicamentDAO;
import dao.FournisseurDAO;
import dao.StockDAO;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/dashboard")
public class DashboardServlet extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        MedicamentDAO medicamentDAO = new MedicamentDAO();
        FournisseurDAO fournisseurDAO = new FournisseurDAO();
        StockDAO stockDAO = new StockDAO();
        
        request.setAttribute("totalMedicaments", medicamentDAO.count());
        request.setAttribute("totalFournisseurs", fournisseurDAO.count());
        request.setAttribute("expirationProche", stockDAO.countExpirationProche(30));
        request.setAttribute("page", "dashboard");
        request.setAttribute("pageTitle", "Dashboard");
        
        request.getRequestDispatcher("/WEB-INF/views/dashboard.jsp").forward(request, response);
    }
}