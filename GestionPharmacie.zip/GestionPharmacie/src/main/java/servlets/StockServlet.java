package servlets;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;  
@WebServlet("/stocks")
public class StockServlet extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
    	HttpSession session = request.getSession();
    	if (session.getAttribute("user") == null) {
    	    response.sendRedirect("login");
    	    return;
    	}    
        
        request.setAttribute("page", "stocks");
        request.setAttribute("pageTitle", "Gestion des stocks");
        
        request.getRequestDispatcher("/WEB-INF/views/stocks.jsp").forward(request, response);
    }
}