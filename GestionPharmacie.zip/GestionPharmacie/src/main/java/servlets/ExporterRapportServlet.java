package servlets;

import dao.MedicamentDAO;
import models.Medicament;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/exporterRapport")
public class ExporterRapportServlet extends HttpServlet {
    private MedicamentDAO medicamentDAO = new MedicamentDAO();
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        response.setContentType("text/csv");
        response.setHeader("Content-Disposition", "attachment; filename=\"rapport_stocks.csv\"");
        
        PrintWriter out = response.getWriter();
        out.println("Code;Nom;Stock actuel;Seuil;Statut");
        
        List<Medicament> medicaments = medicamentDAO.getAllMedicaments();
        for (Medicament m : medicaments) {
            String statut = m.getStockActuel() <= m.getSeuilAlerte() ? "Stock bas" : "Normal";
            out.println(m.getCode() + ";" + m.getNom() + ";" + m.getStockActuel() + ";" + m.getSeuilAlerte() + ";" + statut);
        }
        
        out.flush();
        out.close();
    }
}
