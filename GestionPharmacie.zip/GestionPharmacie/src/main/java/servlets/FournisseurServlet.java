package servlets;

import dao.FournisseurDAO;
import models.Fournisseur;
import java.io.IOException;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/fournisseurs")
public class FournisseurServlet extends HttpServlet {
    private FournisseurDAO fournisseurDAO = new FournisseurDAO();
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        List<Fournisseur> fournisseurs = fournisseurDAO.getAllFournisseurs();
        request.setAttribute("fournisseurs", fournisseurs);
        request.setAttribute("page", "fournisseurs");
        request.setAttribute("pageTitle", "Fournisseurs");
        request.getRequestDispatcher("/WEB-INF/views/fournisseurs.jsp").forward(request, response);
    }
}