package servlets;

import dao.MedicamentDAO;
import models.Medicament;
import java.io.IOException;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/medicaments")
public class MedicamentListServlet extends HttpServlet {
    private MedicamentDAO medicamentDAO = new MedicamentDAO();
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        List<Medicament> medicaments = medicamentDAO.getAllMedicaments();
        request.setAttribute("medicaments", medicaments);
        request.setAttribute("page", "medicaments");
        request.setAttribute("pageTitle", "Médicaments");
        request.getRequestDispatcher("/WEB-INF/views/medicaments.jsp").forward(request, response);
    }
}