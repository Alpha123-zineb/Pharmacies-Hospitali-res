package servlets;

import dao.MedicamentDAO;
import dao.StockDAO;
import models.Medicament;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/alertes")
public class AlerteServlet extends HttpServlet {
    private MedicamentDAO medicamentDAO = new MedicamentDAO();
    private StockDAO stockDAO = new StockDAO();
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        List<Medicament> allMedicaments = medicamentDAO.getAllMedicaments();
        List<Medicament> stockBas = new ArrayList<>();
        
        for (Medicament m : allMedicaments) {
            if (m.getStockActuel() <= m.getSeuilAlerte()) {
                stockBas.add(m);
            }
        }
        
        request.setAttribute("stockBas", stockBas);
        request.setAttribute("expirationCount", stockDAO.countExpirationProche(30));
        request.setAttribute("page", "alertes");
        request.setAttribute("pageTitle", "Alertes");
        request.getRequestDispatcher("/WEB-INF/views/alertes.jsp").forward(request, response);
    }
}