package servlets;

import dao.MedicamentDAO;
import models.Medicament;
import java.io.IOException;
import java.math.BigDecimal;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/ajouter")
public class AjouterMedicamentServlet extends HttpServlet {
    private MedicamentDAO medicamentDAO = new MedicamentDAO();
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        request.setAttribute("page", "medicaments");
        request.setAttribute("pageTitle", "Ajouter médicament");
        request.getRequestDispatcher("/WEB-INF/views/ajouterMedicament.jsp").forward(request, response);
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String code = request.getParameter("code");
        String nom = request.getParameter("nom");
        String description = request.getParameter("description");
        String dosage = request.getParameter("dosage");
        String forme = request.getParameter("forme");
        BigDecimal prixUnitaire = new BigDecimal(request.getParameter("prixUnitaire"));
        int fournisseurId = Integer.parseInt(request.getParameter("fournisseurId"));
        int seuilAlerte = Integer.parseInt(request.getParameter("seuilAlerte"));
        
        Medicament m = new Medicament();
        m.setCode(code);
        m.setNom(nom);
        m.setDescription(description);
        m.setDosage(dosage);
        m.setForme(forme);
        m.setPrixUnitaire(prixUnitaire);
        m.setFournisseurId(fournisseurId);
        m.setSeuilAlerte(seuilAlerte);
        
        medicamentDAO.addMedicament(m);
        response.sendRedirect("medicaments");
    }
}