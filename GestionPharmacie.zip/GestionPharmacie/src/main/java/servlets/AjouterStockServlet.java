package servlets;

import dao.StockDAO;
import java.io.IOException;
import java.sql.Date;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/ajouterStock")
public class AjouterStockServlet extends HttpServlet {
    private StockDAO stockDAO = new StockDAO();
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        int medicamentId = Integer.parseInt(request.getParameter("medicamentId"));
        int quantite = Integer.parseInt(request.getParameter("quantite"));
        String lot = request.getParameter("lot");
        Date dateExpiration = Date.valueOf(request.getParameter("dateExpiration"));
        
        stockDAO.addStock(medicamentId, quantite, lot, dateExpiration);
        response.sendRedirect("medicaments");
    }
}