<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier mon profil - PharmaGest</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .container {
            background: white;
            border-radius: 30px;
            padding: 40px;
            width: 100%;
            max-width: 500px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        .logo { text-align: center; margin-bottom: 30px; }
        .logo i { font-size: 3rem; color: #00b894; }
        .logo h1 { color: #2d3436; margin-top: 10px; }
        .form-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 8px; font-weight: 500; color: #2d3436; }
        input { width: 100%; padding: 12px 15px; border: 1px solid #ddd; border-radius: 12px; font-size: 1rem; }
        input:focus { outline: none; border-color: #00b894; }
        .btn {
            padding: 12px 20px; border: none; border-radius: 12px;
            font-size: 1rem; cursor: pointer; transition: all 0.3s;
        }
        .btn-primary { background: #00b894; color: white; width: 100%; }
        .btn-primary:hover { background: #019874; }
        .btn-secondary { background: #636e72; color: white; text-decoration: none; display: inline-block; text-align: center; }
        .btn-secondary:hover { background: #2d3436; }
        .flex-buttons { display: flex; gap: 15px; margin-top: 20px; }
        .avatar { text-align: center; margin-bottom: 20px; }
        .avatar img { width: 100px; border-radius: 50%; }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">
            <i class="fas fa-user-edit"></i>
            <h1>Modifier mon profil</h1>
        </div>
        <div class="avatar">
            <img src="https://ui-avatars.com/api/?name=Pharmacien&background=00b894&color=fff&size=100">
        </div>
        <form action="modifierProfil" method="post">
            <div class="form-group">
                <label><i class="fas fa-user"></i> Nom complet</label>
                <input type="text" name="nom" value="Dr. Pharmacien" required>
            </div>
            <div class="form-group">
                <label><i class="fas fa-envelope"></i> Email</label>
                <input type="email" name="email" value="pharmacien@pharmagest.ma" required>
            </div>
            <div class="form-group">
                <label><i class="fas fa-phone"></i> Téléphone</label>
                <input type="tel" name="telephone" value="+212 5XX XXX XXX">
            </div>
            <div class="form-group">
                <label><i class="fas fa-building"></i> Établissement</label>
                <input type="text" name="etablissement" value="Hôpital Central">
            </div>
            <div class="form-group">
                <label><i class="fas fa-lock"></i> Nouveau mot de passe</label>
                <input type="password" name="password" placeholder="Laisser vide pour ne pas changer">
            </div>
            <div class="flex-buttons">
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Enregistrer</button>
                <a href="dashboard" class="btn btn-secondary"><i class="fas fa-times"></i> Annuler</a>
            </div>
        </form>
    </div>
</body>
</html>