<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>PharmaGest</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/style.css">
</head>
<body>
<div class="sidebar">
    <div class="sidebar-header">
        <h2>🏥 PharmaGest</h2>
        <p>Pharmacie Hospitalière</p>
    </div>
    <ul class="nav-menu">
        <li class="nav-item"><a href="${pageContext.request.contextPath}/dashboard">📊 Dashboard</a></li>
        <li class="nav-item"><a href="${pageContext.request.contextPath}/medicaments">💊 Médicaments</a></li>
        <li class="nav-item"><a href="${pageContext.request.contextPath}/stocks">📦 Stocks</a></li>
        <li class="nav-item"><a href="${pageContext.request.contextPath}/fournisseurs">🏢 Fournisseurs</a></li>
        <li class="nav-item"><a href="${pageContext.request.contextPath}/alertes">⚠️ Alertes</a></li>
    </ul>
</div>
<div class="main-content">
    <div class="top-bar">
        <div class="page-title">${pageTitle}</div>
        <div>👤 Pharmacien</div>
    </div>