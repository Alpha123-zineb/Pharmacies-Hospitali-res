<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="models.Medicament, dao.MedicamentDAO, java.util.List" %>
<%
    MedicamentDAO medicamentDAO = new MedicamentDAO();
    List<Medicament> medicaments = medicamentDAO.getAllMedicaments();
%>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des stocks - PharmaGest</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }

        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 280px;
            height: 100%;
            background: linear-gradient(180deg, #1a1a2e 0%, #16213e 100%);
            color: white;
            box-shadow: 4px 0 20px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            z-index: 100;
        }

        .logo {
            padding: 25px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .logo i {
            font-size: 3rem;
            color: #00b894;
            margin-bottom: 10px;
        }

        .logo h2 {
            font-size: 1.5rem;
            margin-top: 10px;
        }

        .logo p {
            font-size: 0.8rem;
            opacity: 0.7;
        }

        .nav-menu {
            list-style: none;
            padding: 20px 0;
        }

        .nav-item {
            padding: 12px 25px;
            margin: 5px 15px;
            border-radius: 12px;
            transition: all 0.3s ease;
        }

        .nav-item:hover {
            background: rgba(0,184,148,0.2);
            transform: translateX(5px);
        }

        .nav-item.active {
            background: linear-gradient(90deg, #00b894, #00cec9);
        }

        .nav-item a {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 15px;
            font-size: 1rem;
        }

        .nav-item i {
            width: 25px;
            font-size: 1.2rem;
        }

        .main-content {
            margin-left: 280px;
            padding: 20px;
        }

        .top-bar {
            background: white;
            border-radius: 20px;
            padding: 15px 25px;
            margin-bottom: 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .page-title h1 {
            font-size: 1.5rem;
            color: #2d3436;
        }

        .page-title p {
            font-size: 0.85rem;
            color: #636e72;
            margin-top: 5px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
            background: #f8f9fa;
            padding: 8px 20px;
            border-radius: 50px;
        }

        .user-info img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-bottom: 25px;
        }

        .stat-card {
            background: white;
            border-radius: 20px;
            padding: 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-info h3 {
            font-size: 2rem;
            font-weight: bold;
            color: #2d3436;
        }

        .stat-info p {
            color: #636e72;
            font-size: 0.85rem;
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
        }

        .stat-card.total .stat-icon { background: rgba(52,152,219,0.1); color: #3498db; }
        .stat-card.alert .stat-icon { background: rgba(231,76,60,0.1); color: #e74c3c; }
        .stat-card.expire .stat-icon { background: rgba(241,196,15,0.1); color: #f1c40f; }

        .card {
            background: white;
            border-radius: 20px;
            padding: 20px;
            margin-bottom: 25px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
        }

        .card-header h3 {
            color: #2d3436;
            font-size: 1.2rem;
        }

        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-size: 0.85rem;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-primary {
            background: #3498db;
            color: white;
        }

        .btn-primary:hover {
            background: #2980b9;
            transform: scale(1.02);
        }

        .btn-success {
            background: #00b894;
            color: white;
        }

        .btn-success:hover {
            background: #019874;
        }

        .btn-danger {
            background: #e74c3c;
            color: white;
        }

        .btn-sm {
            padding: 5px 10px;
            font-size: 0.75rem;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #f0f0f0;
        }

        th {
            background: #f8f9fa;
            color: #2d3436;
            font-weight: 600;
        }

        tr:hover {
            background: #f8f9fa;
        }

        .badge {
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 500;
        }

        .badge-success {
            background: #00b894;
            color: white;
        }

        .badge-warning {
            background: #f1c40f;
            color: #2d3436;
        }

        .badge-danger {
            background: #e74c3c;
            color: white;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }

        .modal-content {
            background: white;
            border-radius: 20px;
            padding: 25px;
            width: 90%;
            max-width: 500px;
            animation: fadeIn 0.3s;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #2d3436;
        }

        .form-group input, .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 10px;
            font-size: 0.9rem;
        }

        .form-group input:focus {
            outline: none;
            border-color: #00b894;
        }

        .toast {
            position: fixed;
            bottom: 30px;
            right: 30px;
            background: #00b894;
            color: white;
            padding: 12px 20px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
            transform: translateX(400px);
            transition: transform 0.3s;
            z-index: 1100;
        }

        .toast.show {
            transform: translateX(0);
        }

        @media (max-width: 768px) {
            .sidebar { width: 70px; }
            .sidebar .logo h2, .sidebar .logo p, .nav-item span { display: none; }
            .main-content { margin-left: 70px; }
            .stats-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="logo">
            <i class="fas fa-hospital-user"></i>
            <h2>PharmaGest</h2>
            <p>Pharmacie Hospitalière</p>
        </div>
        <ul class="nav-menu">
            <li class="nav-item"><a href="dashboard"><i class="fas fa-chart-line"></i><span>Dashboard</span></a></li>
            <li class="nav-item"><a href="medicaments"><i class="fas fa-capsules"></i><span>Médicaments</span></a></li>
            <li class="nav-item active"><a href="stocks"><i class="fas fa-boxes"></i><span>Stocks</span></a></li>
            <li class="nav-item"><a href="fournisseurs"><i class="fas fa-truck"></i><span>Fournisseurs</span></a></li>
            <li class="nav-item"><a href="alertes"><i class="fas fa-bell"></i><span>Alertes</span></a></li>
        </ul>
    </div>

    <div class="main-content">
        <div class="top-bar">
            <div class="page-title">
                <h1><i class="fas fa-boxes"></i> Gestion des stocks</h1>
                <p><i class="fas fa-calendar-alt"></i> <span id="currentDate"></span></p>
            </div>
            <div class="user-info">
                <img src="https://ui-avatars.com/api/?name=Pharmacien&background=00b894&color=fff" alt="Avatar">
                <span>Dr. Pharmacien</span>
            </div>
        </div>

        <% 
            int totalStock = 0;
            int stockCritique = 0;
            for (Medicament m : medicaments) {
                totalStock += m.getStockActuel();
                if (m.getStockActuel() <= m.getSeuilAlerte()) stockCritique++;
            }
        %>

        <div class="stats-grid">
            <div class="stat-card total">
                <div class="stat-info">
                    <h3><%= totalStock %></h3>
                    <p>Unités en stock</p>
                </div>
                <div class="stat-icon"><i class="fas fa-cubes"></i></div>
            </div>
            <div class="stat-card alert">
                <div class="stat-info">
                    <h3><%= stockCritique %></h3>
                    <p>Médicaments en alerte</p>
                </div>
                <div class="stat-icon"><i class="fas fa-exclamation-triangle"></i></div>
            </div>
            <div class="stat-card expire">
                <div class="stat-info">
                    <h3>0</h3>
                    <p>Lots expirés</p>
                </div>
                <div class="stat-icon"><i class="fas fa-hourglass-end"></i></div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-list"></i> État des stocks par médicament</h3>
                <button class="btn btn-success" onclick="openEntreeStock()"><i class="fas fa-plus"></i> Entrée de stock</button>
            </div>
            <div style="overflow-x: auto;">
                <table>
                    <thead>
                        <tr>
                            <th>Code</th><th>Nom</th><th>Stock actuel</th><th>Seuil</th><th>Statut</th><th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <% for (Medicament m : medicaments) { 
                            String statut = "";
                            String badgeClass = "";
                            if (m.getStockActuel() <= 0) {
                                statut = "Rupture";
                                badgeClass = "badge-danger";
                            } else if (m.getStockActuel() <= m.getSeuilAlerte()) {
                                statut = "Critique";
                                badgeClass = "badge-warning";
                            } else {
                                statut = "Normal";
                                badgeClass = "badge-success";
                            }
                        %>
                            <tr>
                                <td><%= m.getCode() %></td>
                                <td><%= m.getNom() %></td>
                                <td><strong><%= m.getStockActuel() %></strong></td>
                                <td><%= m.getSeuilAlerte() %></td>
                                <td><span class="badge <%= badgeClass %>"><%= statut %></span></td>
                                <td>
                                    <button class="btn btn-primary btn-sm" onclick="openReapprovisionner(<%= m.getId() %>, '<%= m.getNom() %>')"><i class="fas fa-shopping-cart"></i> Réapprovisionner</button>
                                </td>
                            </tr>
                        <% } %>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-chart-line"></i> Niveaux de stock</h3>
                <i class="fas fa-chart-simple"></i>
            </div>
            <% for (Medicament m : medicaments) { 
                int pourcentage = (m.getStockActuel() * 100 / (m.getSeuilAlerte() * 3));
                if (pourcentage > 100) pourcentage = 100;
                String barColor = pourcentage < 30 ? "danger" : (pourcentage < 60 ? "warning" : "success");
            %>
                <div style="margin-bottom: 15px;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                        <span><%= m.getNom() %></span>
                        <span><%= m.getStockActuel() %> / <%= m.getSeuilAlerte() * 3 %></span>
                    </div>
                    <div class="progress-bar" style="height: 8px; background: #ecf0f1; border-radius: 10px; overflow: hidden;">
                        <div class="progress-fill <%= barColor %>" style="width: <%= pourcentage %>%; height: 100%; background: <%= barColor == "danger" ? "#e74c3c" : (barColor == "warning" ? "#f1c40f" : "#00b894") %>; border-radius: 10px;"></div>
                    </div>
                </div>
            <% } %>
        </div>
    </div>

    <!-- Modal Entrée Stock -->
    <div id="stockModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-boxes"></i> Entrée de stock</h3>
                <i class="fas fa-times" style="cursor: pointer;" onclick="closeModal()"></i>
            </div>
            <form action="ajouterStock" method="post">
                <input type="hidden" name="medicamentId" id="medicamentId">
                <div class="form-group">
                    <label><i class="fas fa-capsules"></i> Médicament</label>
                    <input type="text" id="medicamentNom" class="form-control" readonly>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-weight-hanging"></i> Quantité</label>
                    <input type="number" name="quantite" class="form-control" required min="1">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-barcode"></i> Numéro de lot</label>
                    <input type="text" name="lot" class="form-control" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-calendar"></i> Date d'expiration</label>
                    <input type="date" name="dateExpiration" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-success" style="width: 100%;"><i class="fas fa-check"></i> Valider l'entrée</button>
            </form>
        </div>
    </div>

    <!-- Modal Réapprovisionnement -->
    <div id="reapproModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-shopping-cart"></i> Réapprovisionnement</h3>
                <i class="fas fa-times" style="cursor: pointer;" onclick="closeReapproModal()"></i>
            </div>
            <form action="ajouterStock" method="post">
                <input type="hidden" name="medicamentId" id="reapproMedicamentId">
                <div class="form-group">
                    <label><i class="fas fa-capsules"></i> Médicament</label>
                    <input type="text" id="reapproMedicamentNom" class="form-control" readonly>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-weight-hanging"></i> Quantité à commander</label>
                    <input type="number" name="quantite" class="form-control" required min="1" value="100">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-barcode"></i> Numéro de lot</label>
                    <input type="text" name="lot" class="form-control" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-calendar"></i> Date d'expiration</label>
                    <input type="date" name="dateExpiration" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary" style="width: 100%;"><i class="fas fa-truck"></i> Commander</button>
            </form>
        </div>
    </div>

    <div id="toast" class="toast">
        <i class="fas fa-check-circle"></i>
        <span id="toastMessage">Action effectuée</span>
    </div>

    <script>
        document.getElementById('currentDate').innerText = new Date().toLocaleDateString('fr-FR', { year: 'numeric', month: 'long', day: 'numeric' });

        function openEntreeStock() {
            document.getElementById('medicamentId').value = '';
            document.getElementById('medicamentNom').value = '';
            document.getElementById('stockModal').style.display = 'flex';
        }

        function openReapprovisionner(id, nom) {
            document.getElementById('reapproMedicamentId').value = id;
            document.getElementById('reapproMedicamentNom').value = nom;
            document.getElementById('reapproModal').style.display = 'flex';
        }

        function closeModal() {
            document.getElementById('stockModal').style.display = 'none';
        }

        function closeReapproModal() {
            document.getElementById('reapproModal').style.display = 'none';
        }

        function showToast(message) {
            document.getElementById('toastMessage').innerText = message;
            document.getElementById('toast').classList.add('show');
            setTimeout(() => {
                document.getElementById('toast').classList.remove('show');
            }, 3000);
        }

        window.onclick = function(event) {
            if (event.target == document.getElementById('stockModal')) closeModal();
            if (event.target == document.getElementById('reapproModal')) closeReapproModal();
        }
    </script>
</body>
</html>