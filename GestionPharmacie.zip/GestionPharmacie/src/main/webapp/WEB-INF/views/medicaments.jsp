<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="models.Medicament, java.util.List" %>
<%
    List<Medicament> medicaments = (List<Medicament>) request.getAttribute("medicaments");
    if (medicaments == null) medicaments = new java.util.ArrayList<>();
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Médicaments - PharmaGest</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background: #f0f2f5; }
        .sidebar { position: fixed; left: 0; top: 0; width: 250px; height: 100%; background: #2c3e50; color: white; }
        .sidebar h2 { padding: 20px; text-align: center; }
        .sidebar a { display: block; padding: 15px 20px; color: white; text-decoration: none; }
        .sidebar a:hover, .sidebar a.active { background: #34495e; }
        .content { margin-left: 250px; padding: 20px; }
        .header { background: white; padding: 15px; border-radius: 10px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; }
        .table-container { background: white; border-radius: 10px; padding: 20px; overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #f8f9fa; }
        .stock-low { background-color: #ffe5e5; }
        .badge { padding: 3px 8px; border-radius: 10px; font-size: 12px; }
        .badge-danger { background: #e74c3c; color: white; }
        .badge-success { background: #27ae60; color: white; }
        .btn { display: inline-block; padding: 5px 10px; border-radius: 5px; text-decoration: none; margin: 2px; border: none; cursor: pointer; font-size: 12px; }
        .btn-primary { background: #3498db; color: white; }
        .btn-danger { background: #e74c3c; color: white; }
        .btn-success { background: #27ae60; color: white; }
        .btn-warning { background: #f39c12; color: white; }
        .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); justify-content: center; align-items: center; z-index: 1000; }
        .modal-content { background: white; border-radius: 10px; padding: 20px; width: 400px; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; }
        .form-control { width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 5px; }
    </style>
</head>
<body>
<div class="sidebar">
    <h2>🏥 PharmaGest</h2>
    <a href="dashboard">📊 Dashboard</a>
    <a href="medicaments" class="active">💊 Médicaments</a>
    <a href="fournisseurs">🏢 Fournisseurs</a>
    <a href="alertes">⚠️ Alertes</a>
</div>
<div class="content">
    <div class="header">
        <h2>Gestion des médicaments</h2>
        <a href="ajouter" class="btn btn-success">+ Nouveau médicament</a>
    </div>
    <div class="table-container">
        <table>
            <thead>
                <tr><th>Code</th><th>Nom</th><th>Dosage</th><th>Forme</th><th>Prix</th><th>Stock</th><th>Seuil</th><th>Actions</th></tr>
            </thead>
            <tbody>
            <% for (Medicament m : medicaments) { 
                String rowClass = (m.getStockActuel() <= m.getSeuilAlerte()) ? "stock-low" : "";
            %>
                <tr class="<%= rowClass %>">
                    <td><%= m.getCode() %></td>
                    <td><%= m.getNom() %></td>
                    <td><%= m.getDosage() != null ? m.getDosage() : "-" %></td>
                    <td><%= m.getForme() != null ? m.getForme() : "-" %></td>
                    <td><%= String.format("%.2f", m.getPrixUnitaire()) %> DH</td>
                    <td><span class="badge <%= m.getStockActuel() <= m.getSeuilAlerte() ? "badge-danger" : "badge-success" %>"><%= m.getStockActuel() %></span></td>
                    <td><%= m.getSeuilAlerte() %></td>
                    <td>
                        <a href="modifier?id=<%= m.getId() %>" class="btn btn-primary">✏️</a>
                        <a href="supprimer?id=<%= m.getId() %>" class="btn btn-danger" onclick="return confirm('Supprimer ce médicament ?')">🗑️</a>
                        <button class="btn btn-success" onclick="openStockModal(<%= m.getId() %>, '<%= m.getNom() %>')">📦</button>
                    </td>
                </tr>
            <% } %>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Entrée Stock -->
<div id="stockModal" class="modal">
    <div class="modal-content">
        <h3>📦 Ajouter du stock</h3>
        <form action="ajouterStock" method="post">
            <input type="hidden" name="medicamentId" id="medicamentId">
            <div class="form-group">
                <label>Médicament</label>
                <input type="text" id="medicamentNom" class="form-control" readonly>
            </div>
            <div class="form-group">
                <label>Quantité</label>
                <input type="number" name="quantite" class="form-control" required min="1">
            </div>
            <div class="form-group">
                <label>Lot</label>
                <input type="text" name="lot" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Date d'expiration</label>
                <input type="date" name="dateExpiration" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-success">Valider</button>
            <button type="button" class="btn btn-primary" onclick="closeStockModal()">Annuler</button>
        </form>
    </div>
</div>

<script>
function openStockModal(id, nom) {
    document.getElementById('medicamentId').value = id;
    document.getElementById('medicamentNom').value = nom;
    document.getElementById('stockModal').style.display = 'flex';
}
function closeStockModal() {
    document.getElementById('stockModal').style.display = 'none';
}
</script>
</body>
</html>