<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="models.Fournisseur, java.util.List" %>
<%
    List<Fournisseur> fournisseurs = (List<Fournisseur>) request.getAttribute("fournisseurs");
    if (fournisseurs == null) fournisseurs = new java.util.ArrayList<>();
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Fournisseurs - PharmaGest</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial; background: #f0f2f5; }
        .sidebar { position: fixed; left: 0; top: 0; width: 250px; height: 100%; background: #2c3e50; color: white; }
        .sidebar h2 { padding: 20px; text-align: center; }
        .sidebar a { display: block; padding: 15px 20px; color: white; text-decoration: none; }
        .sidebar a:hover, .sidebar a.active { background: #34495e; }
        .content { margin-left: 250px; padding: 20px; }
        .header { background: white; padding: 15px; border-radius: 10px; margin-bottom: 20px; }
        .table-container { background: white; border-radius: 10px; padding: 20px; overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #f8f9fa; }
        .btn { display: inline-block; padding: 5px 10px; border-radius: 5px; text-decoration: none; margin: 2px; }
        .btn-primary { background: #3498db; color: white; }
        .btn-danger { background: #e74c3c; color: white; }
    </style>
</head>
<body>
<div class="sidebar">
    <h2>🏥 PharmaGest</h2>
    <a href="dashboard">📊 Dashboard</a>
    <a href="medicaments">💊 Médicaments</a>
    <a href="fournisseurs" class="active">🏢 Fournisseurs</a>
    <a href="alertes">⚠️ Alertes</a>
</div>
<div class="content">
    <div class="header"><h2>🏢 Gestion des fournisseurs</h2></div>
    <div class="table-container">
        <table>
            <thead>
                <tr><th>ID</th><th>Nom</th><th>Contact</th><th>Téléphone</th><th>Email</th><th>Adresse</th>
            </tr>
            </thead>
            <tbody>
            <% for (Fournisseur f : fournisseurs) { %>
                <tr>
                    <td><%= f.getId() %></td>
                    <td><%= f.getNom() %></td>
                    <td><%= f.getContact() != null ? f.getContact() : "-" %></td>
                    <td><%= f.getTelephone() != null ? f.getTelephone() : "-" %></td>
                    <td><%= f.getEmail() != null ? f.getEmail() : "-" %></td>
                    <td><%= f.getAdresse() != null ? f.getAdresse() : "-" %></td>
                </tr>
            <% } %>
            </tbody>
        </table>
    </div>
</div>
<!-- Carte des fournisseurs -->
<div class="section-card" style="margin-top: 20px;">
    <div class="section-header">
        <h3><i class="fas fa-map-marker-alt"></i> Localisation des fournisseurs</h3>
    </div>
    <div id="map" style="height: 400px; border-radius: 15px; overflow: hidden;"></div>
</div>

<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
    var map = L.map('map').setView([33.5731, -7.5898], 12);
    L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OSM</a>'
    }).addTo(map);
    
    // Marqueurs pour les fournisseurs
    <% 
        // Coordonnées fictives pour Casablanca, Rabat, Marrakech
        String[][] coords = {{"PharmaPlus", "33.5731", "-7.5898"}, 
                              {"MediTech", "34.0209", "-6.8416"}, 
                              {"Biopharm", "31.6295", "-7.9811"}};
        for (String[] c : coords) {
    %>
        L.marker([<%= c[1] %>, <%= c[2] %>])
            .addTo(map)
            .bindPopup("<strong><%= c[0] %></strong><br>Fournisseur pharmaceutique");
    <% } %>
</script>
</body>
</html>