<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="models.Medicament, models.Fournisseur, dao.MedicamentDAO, dao.FournisseurDAO, dao.StockDAO, java.util.List" %>
<%
    MedicamentDAO medicamentDAO = new MedicamentDAO();
    FournisseurDAO fournisseurDAO = new FournisseurDAO();
    StockDAO stockDAO = new StockDAO();
    
    List<Medicament> medicaments = medicamentDAO.getAllMedicaments();
    List<Fournisseur> fournisseurs = fournisseurDAO.getAllFournisseurs();
    
    int totalMedicaments = medicaments.size();
    int totalFournisseurs = fournisseurs.size();
    int stockBas = 0;
    int expirationProche = stockDAO.countExpirationProche(30);
    
    for (Medicament m : medicaments) {
        if (m.getStockActuel() <= m.getSeuilAlerte()) stockBas++;
    }
%>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PharmaGest - Pharmacie Hospitalière</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f0f2f5; }
        
        .sidebar {
            position: fixed; left: 0; top: 0; width: 260px; height: 100%;
            background: linear-gradient(180deg, #1a1a2e 0%, #16213e 100%);
            color: white; box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            overflow-y: auto; z-index: 100;
        }
        .logo { padding: 25px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.1); }
        .logo i { font-size: 2.5rem; color: #00b894; }
        .logo h2 { margin-top: 10px; font-size: 1.3rem; }
        .logo p { font-size: 0.7rem; opacity: 0.7; }
        
        .nav-item {
            padding: 12px 20px; margin: 5px 15px; border-radius: 10px;
            cursor: pointer; transition: all 0.3s;
        }
        .nav-item:hover { background: rgba(0,184,148,0.2); }
        .nav-item.active { background: #00b894; }
        .nav-item i { width: 25px; margin-right: 10px; }
        
        .main-content { margin-left: 260px; padding: 20px; }
        
        .top-bar {
            background: white; border-radius: 15px; padding: 15px 25px;
            margin-bottom: 20px; display: flex; justify-content: space-between;
            align-items: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .page-title h1 { font-size: 1.3rem; color: #2d3436; }
        .user-info { display: flex; align-items: center; gap: 10px; }
        .user-info img { width: 40px; height: 40px; border-radius: 50%; }
        
        .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 25px; }
        .stat-card {
            background: white; border-radius: 15px; padding: 20px;
            display: flex; justify-content: space-between; align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1); cursor: pointer;
            transition: transform 0.2s;
        }
        .stat-card:hover { transform: translateY(-3px); }
        .stat-info h3 { font-size: 2rem; color: #2d3436; }
        .stat-info p { color: #636e72; font-size: 0.8rem; }
        .stat-icon { width: 50px; height: 50px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; }
        .stat-card.blue .stat-icon { background: rgba(52,152,219,0.1); color: #3498db; }
        .stat-card.red .stat-icon { background: rgba(231,76,60,0.1); color: #e74c3c; }
        .stat-card.orange .stat-icon { background: rgba(241,196,15,0.1); color: #f1c40f; }
        .stat-card.green .stat-icon { background: rgba(0,184,148,0.1); color: #00b894; }
        
        .welcome-banner {
            background: linear-gradient(135deg, #00b894, #00cec9);
            border-radius: 15px; padding: 20px; margin-bottom: 25px;
            color: white; display: flex; justify-content: space-between; align-items: center;
        }
        
        .section-card {
            background: white; border-radius: 15px; padding: 20px;
            margin-bottom: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .section-header {
            display: flex; justify-content: space-between; align-items: center;
            padding-bottom: 15px; border-bottom: 2px solid #f0f0f0;
            margin-bottom: 15px;
        }
        .alert-item {
            padding: 12px 0; border-bottom: 1px solid #f0f0f0;
            display: flex; justify-content: space-between; align-items: center;
        }
        .btn-small {
            background: #3498db; color: white; border: none;
            padding: 5px 12px; border-radius: 8px; cursor: pointer;
            text-decoration: none; display: inline-block;
            font-size: 0.75rem;
        }
        .btn-small:hover { background: #2980b9; }
        .btn-success { background: #00b894; }
        .btn-success:hover { background: #019874; }
        .progress-bar { height: 6px; background: #ecf0f1; border-radius: 10px; margin: 8px 0; }
        .progress-fill { height: 100%; border-radius: 10px; }
        .progress-fill.danger { background: #e74c3c; }
        .progress-fill.warning { background: #f1c40f; }
        
        .table-responsive { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #eee; }
        th { background: #f8f9fa; }
        .badge { padding: 3px 8px; border-radius: 10px; font-size: 0.7rem; }
        .badge-danger { background: #e74c3c; color: white; }
        .badge-success { background: #00b894; color: white; }
        .badge-warning { background: #f1c40f; color: #2d3436; }
        
        .tab-content { display: none; }
        .tab-content.active { display: block; }
        
        @media (max-width: 768px) {
            .sidebar { width: 70px; }
            .sidebar .logo h2, .sidebar .logo p, .nav-item span { display: none; }
            .main-content { margin-left: 70px; }
            .stats-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
<div class="sidebar">
    <div class="logo">
        <i class="fas fa-hospital-user"></i>
        <h2>PharmaGest</h2>
        <p>Pharmacie Hospitalière</p>
    </div>
    <div class="nav-item active" data-tab="dashboard">
        <i class="fas fa-chart-line"></i> <span>Dashboard</span>
    </div>
    <div class="nav-item" data-tab="medicaments">
        <i class="fas fa-capsules"></i> <span>Médicaments</span>
    </div>
    <div class="nav-item" data-tab="stocks">
        <i class="fas fa-boxes"></i> <span>Stocks</span>
    </div>
    <div class="nav-item" data-tab="fournisseurs">
        <i class="fas fa-truck"></i> <span>Fournisseurs</span>
    </div>
    <div class="nav-item" data-tab="alertes">
        <i class="fas fa-bell"></i> <span>Alertes</span>
    </div>
    <div class="nav-item" data-tab="profile">
        <i class="fas fa-user-md"></i> <span>Profil</span>
    </div>
</div>

<div class="main-content">
    <div class="top-bar">
        <div class="page-title"><h1 id="pageTitle">Tableau de bord</h1></div>
        <div class="user-info">
            <img src="https://ui-avatars.com/api/?name=Pharmacien&background=00b894&color=fff">
            <span>Dr. Pharmacien</span>
        </div>
    </div>

    <!-- Dashboard Tab -->
    <div id="dashboard-tab" class="tab-content active">
        <div class="welcome-banner">
            <div><h2>👋 Bonjour, Pharmacien !</h2><p>Bienvenue dans votre espace de gestion pharmaceutique.</p></div>
            <i class="fas fa-chart-simple" style="font-size: 3rem;"></i>
        </div>
        
        <div class="stats-grid">
            <div class="stat-card blue"><div class="stat-info"><h3><%= totalMedicaments %></h3><p>Médicaments</p></div><div class="stat-icon"><i class="fas fa-capsules"></i></div></div>
            <div class="stat-card red"><div class="stat-info"><h3><%= stockBas %></h3><p>Stock critique</p></div><div class="stat-icon"><i class="fas fa-exclamation-triangle"></i></div></div>
            <div class="stat-card orange"><div class="stat-info"><h3><%= expirationProche %></h3><p>Expirations (< 30j)</p></div><div class="stat-icon"><i class="fas fa-hourglass-half"></i></div></div>
            <div class="stat-card green"><div class="stat-info"><h3><%= totalFournisseurs %></h3><p>Fournisseurs</p></div><div class="stat-icon"><i class="fas fa-truck"></i></div></div>
        </div>
        
        <div class="section-card">
            <div class="section-header"><h3><i class="fas fa-bell"></i> Alertes de rupture</h3></div>
            <% boolean hasAlert = false; 
               for (Medicament m : medicaments) { 
                   if (m.getStockActuel() <= m.getSeuilAlerte()) { 
                       hasAlert = true; 
            %>
            <div class="alert-item">
                <div>
                    <strong><%= m.getNom() %></strong>
                    <div class="progress-bar"><div class="progress-fill danger" style="width: <%= (m.getStockActuel() * 100 / m.getSeuilAlerte()) %>%"></div></div>
                    <small>Stock: <%= m.getStockActuel() %> / Seuil: <%= m.getSeuilAlerte() %></small>
                </div>
                <button class="btn-small" onclick="window.location.href='commander?id=<%= m.getId() %>&nom=<%= m.getNom() %>'">Commander</button>
            </div>
            <% } } if (!hasAlert) { %>
            <p style="text-align:center; color:#00b894;">✅ Aucune alerte de rupture</p>
            <% } %>
        </div>
        
        <!-- Carte de localisation -->
        <div class="section-card">
            <div class="section-header">
                <h3><i class="fas fa-map-marker-alt"></i> Localisation des fournisseurs</h3>
                <i class="fas fa-building"></i>
            </div>
            <div id="map" style="height: 400px; border-radius: 15px; overflow: hidden; margin-top: 10px;"></div>
            <p style="text-align: center; margin-top: 10px; font-size: 0.8rem; color: #636e72;">
                <i class="fas fa-info-circle"></i> Principaux fournisseurs pharmaceutiques au Maroc
            </p>
        </div>
    </div>

    <!-- Médicaments Tab -->
    <div id="medicaments-tab" class="tab-content">
        <div class="section-card">
            <div class="section-header"><h3><i class="fas fa-list"></i> Liste des médicaments</h3><a href="ajouter" class="btn-small btn-success">+ Ajouter</a></div>
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr><th>Code</th><th>Nom</th><th>Dosage</th><th>Forme</th><th>Prix</th><th>Stock</th><th>Seuil</th><th>Actions</th></tr>
                    </thead>
                    <tbody>
                    <% for (Medicament m : medicaments) { %>
                        <tr>
                            <td><%= m.getCode() %></td>
                            <td><%= m.getNom() %></td>
                            <td><%= m.getDosage() != null ? m.getDosage() : "-" %></td>
                            <td><%= m.getForme() != null ? m.getForme() : "-" %></td>
                            <td><%= String.format("%.2f", m.getPrixUnitaire()) %> DH</td>
                            <td><span class="badge <%= m.getStockActuel() <= m.getSeuilAlerte() ? "badge-danger" : "badge-success" %>"><%= m.getStockActuel() %></span></td>
                            <td><%= m.getSeuilAlerte() %></td>
                            <td>
                                <a href="modifier?id=<%= m.getId() %>" style="color:#3498db; margin-right:10px;"><i class="fas fa-edit"></i></a>
                                <a href="supprimer?id=<%= m.getId() %>" style="color:#e74c3c;" onclick="return confirm('Supprimer ?')"><i class="fas fa-trash"></i></a>
                                <button class="btn-small" style="margin-left:5px;" onclick="openStockModal(<%= m.getId() %>, '<%= m.getNom() %>')">+ Stock</button>
                            </td>
                        </tr>
                    <% } %>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Stocks Tab -->
    <div id="stocks-tab" class="tab-content">
        <div class="section-card">
            <div class="section-header"><h3><i class="fas fa-boxes"></i> État des stocks</h3></div>
            <div class="table-responsive">
                <table class="data-table">
                    <thead><tr><th>Médicament</th><th>Stock actuel</th><th>Seuil</th><th>Statut</th><th>Action</th></tr></thead>
                    <tbody>
                    <% for (Medicament m : medicaments) { 
                        String statut = m.getStockActuel() <= 0 ? "Rupture" : (m.getStockActuel() <= m.getSeuilAlerte() ? "Critique" : "Normal");
                        String badgeClass = m.getStockActuel() <= 0 ? "badge-danger" : (m.getStockActuel() <= m.getSeuilAlerte() ? "badge-warning" : "badge-success");
                    %>
                        <tr>
                            <td><%= m.getNom() %></td>
                            <td><strong><%= m.getStockActuel() %></strong></td>
                            <td><%= m.getSeuilAlerte() %></td>
                            <td><span class="badge <%= badgeClass %>"><%= statut %></span></td>
                            <td><button class="btn-small" onclick="openStockModal(<%= m.getId() %>, '<%= m.getNom() %>')">Réapprovisionner</button></td>
                        </tr>
                    <% } %>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Fournisseurs Tab -->
    <div id="fournisseurs-tab" class="tab-content">
        <div class="section-card">
            <div class="section-header"><h3><i class="fas fa-truck"></i> Liste des fournisseurs</h3></div>
            <div class="table-responsive">
                <table class="data-table">
                    <thead><tr><th>ID</th><th>Nom</th><th>Contact</th><th>Téléphone</th><th>Email</th><th>Adresse</th></tr></thead>
                    <tbody>
                    <% for (Fournisseur f : fournisseurs) { %>
                        <tr>
                            <td><%= f.getId() %></td>
                            <td><%= f.getNom() %></td>
                            <td><%= f.getContact() != null ? f.getContact() : "-" %></td>
                            <td><%= f.getTelephone() != null ? f.getTelephone() : "-" %></td>
                            <td><%= f.getEmail() != null ? f.getEmail() : "-" %></td>
                            <td><%= f.getAdresse() != null ? f.getAdresse() : "-" %></td>
                        </tr>
                    <% } %>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Alertes Tab -->
    <div id="alertes-tab" class="tab-content">
        <div class="section-card">
            <div class="section-header"><h3><i class="fas fa-bell"></i> Centre d'alertes</h3></div>
            <% boolean hasAlerte = false; 
               for (Medicament m : medicaments) { 
                   if (m.getStockActuel() <= m.getSeuilAlerte()) { 
                       hasAlerte = true; 
            %>
            <div class="alert-item">
                <div>
                    <strong><%= m.getNom() %></strong>
                    <div class="progress-bar"><div class="progress-fill danger" style="width: <%= (m.getStockActuel() * 100 / m.getSeuilAlerte()) %>%"></div></div>
                    <small>Stock: <%= m.getStockActuel() %> / Seuil: <%= m.getSeuilAlerte() %></small>
                </div>
                <button class="btn-small" onclick="window.location.href='commander?id=<%= m.getId() %>&nom=<%= m.getNom() %>'">Commander</button>
            </div>
            <% } } if (!hasAlerte) { %>
            <p style="text-align:center; color:#00b894;">✅ Aucune alerte active</p>
            <% } %>
        </div>
    </div>

    <!-- Profil Tab -->
    <div id="profile-tab" class="tab-content">
        <div class="section-card">
            <div class="section-header"><h3><i class="fas fa-user-circle"></i> Mon profil</h3></div>
            <div style="text-align: center;">
                <img src="https://ui-avatars.com/api/?name=Pharmacien&background=00b894&color=fff&size=100" style="width: 100px; border-radius: 50%; margin-bottom: 15px;">
                <h3>Dr. Pharmacien</h3>
                <p>Pharmacien Hospitalier</p>
                <div style="background: #f8f9fa; padding: 15px; border-radius: 10px; margin: 15px 0;">
                    <p><i class="fas fa-envelope"></i> pharmacien@pharmagest.ma</p>
                    <p><i class="fas fa-phone"></i> +212 5XX XXX XXX</p>
                    <p><i class="fas fa-building"></i> Hôpital Central</p>
                </div>
                <a href="modifierProfil" class="btn-small" style="display: inline-block;"><i class="fas fa-user-edit"></i> Modifier profil</a>
                <a href="exporterRapport" class="btn-small btn-success" style="display: inline-block; margin-left: 10px;"><i class="fas fa-file-excel"></i> Exporter CSV</a>
            </div>
        </div>
    </div>
</div>

<!-- Modal Stock -->
<div id="stockModal" class="modal" style="display: none; position: fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); justify-content:center; align-items:center; z-index:1000;">
    <div style="background:white; border-radius:20px; padding:30px; width:400px;">
        <div style="display:flex; justify-content:space-between; margin-bottom:20px;">
            <h3><i class="fas fa-boxes"></i> Ajouter du stock</h3>
            <i class="fas fa-times" onclick="closeStockModal()" style="cursor:pointer;"></i>
        </div>
        <form action="ajouterStock" method="post">
            <input type="hidden" name="medicamentId" id="medicamentId">
            <div class="form-group" style="margin-bottom:15px;">
                <label>Médicament</label>
                <input type="text" id="medicamentNom" style="width:100%; padding:8px; border:1px solid #ddd; border-radius:8px;" readonly>
            </div>
            <div class="form-group" style="margin-bottom:15px;">
                <label>Quantité</label>
                <input type="number" name="quantite" style="width:100%; padding:8px; border:1px solid #ddd; border-radius:8px;" required min="1">
            </div>
            <div class="form-group" style="margin-bottom:15px;">
                <label>Lot</label>
                <input type="text" name="lot" style="width:100%; padding:8px; border:1px solid #ddd; border-radius:8px;" required>
            </div>
            <div class="form-group" style="margin-bottom:15px;">
                <label>Date expiration</label>
                <input type="date" name="dateExpiration" style="width:100%; padding:8px; border:1px solid #ddd; border-radius:8px;" required>
            </div>
            <button type="submit" style="background:#00b894; color:white; border:none; padding:10px 15px; border-radius:8px; width:100%; cursor:pointer;">Ajouter stock</button>
        </form>
    </div>
</div>

<script>
    // Navigation entre les onglets
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', function() {
            document.querySelectorAll('.nav-item').forEach(nav => nav.classList.remove('active'));
            this.classList.add('active');
            
            let tabName = this.getAttribute('data-tab');
            document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
            document.getElementById(tabName + '-tab').classList.add('active');
            
            let titles = {
                dashboard: 'Tableau de bord',
                medicaments: 'Médicaments',
                stocks: 'Stocks',
                fournisseurs: 'Fournisseurs',
                alertes: 'Alertes',
                profile: 'Mon profil'
            };
            document.getElementById('pageTitle').innerText = titles[tabName] || 'PharmaGest';
        });
    });
    
    // Modal Stock
    function openStockModal(id, nom) {
        document.getElementById('medicamentId').value = id;
        document.getElementById('medicamentNom').value = nom;
        document.getElementById('stockModal').style.display = 'flex';
    }
    
    function closeStockModal() {
        document.getElementById('stockModal').style.display = 'none';
    }
    
    // Fermer modal en cliquant à l'extérieur
    window.onclick = function(event) {
        let modal = document.getElementById('stockModal');
        if (event.target == modal) {
            modal.style.display = 'none';
        }
    }
    
    // Initialisation de la carte (Map)
    function initMap() {
        var map = L.map('map').setView([31.7917, -7.0926], 6);
        
        L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OSM</a>'
        }).addTo(map);
        
        var fournisseursMap = [
            { nom: "PharmaPlus Maroc", lat: 33.5731, lng: -7.5898, ville: "Casablanca" },
            { nom: "MediTech Maroc", lat: 34.0209, lng: -6.8416, ville: "Rabat" },
            { nom: "BioPharm", lat: 31.6295, lng: -7.9811, ville: "Marrakech" },
            { nom: "Santé Pharma", lat: 34.0375, lng: -4.9998, ville: "Fès" },
            { nom: "Global Medic", lat: 35.7595, lng: -5.8340, ville: "Tanger" },
            { nom: "MediSud", lat: 30.4278, lng: -9.5981, ville: "Agadir" },
            { nom: "PharmaEst", lat: 34.6851, lng: -1.9114, ville: "Oujda" }
        ];
        
        fournisseursMap.forEach(function(f) {
            L.marker([f.lat, f.lng])
                .addTo(map)
                .bindPopup("<strong>" + f.nom + "</strong><br>" + f.ville);
        });
    }
    
    // Attendre que la page soit chargée
    document.addEventListener('DOMContentLoaded', function() {
        if (document.getElementById('map')) {
            initMap();
        }
    });
</script>
</body>
</html>