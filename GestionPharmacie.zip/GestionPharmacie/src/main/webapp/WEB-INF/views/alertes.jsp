<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="models.Medicament, java.util.List" %>
<%
    List<Medicament> stockBas = (List<Medicament>) request.getAttribute("stockBas");
    Integer expirationCount = (Integer) request.getAttribute("expirationCount");
    if (stockBas == null) stockBas = new java.util.ArrayList<>();
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Alertes - PharmaGest</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial; background: #f0f2f5; }
        .sidebar { position: fixed; left: 0; top: 0; width: 250px; height: 100%; background: #2c3e50; color: white; }
        .sidebar h2 { padding: 20px; text-align: center; }
        .sidebar a { display: block; padding: 15px 20px; color: white; text-decoration: none; }
        .sidebar a:hover, .sidebar a.active { background: #34495e; }
        .content { margin-left: 250px; padding: 20px; }
        .header { background: white; padding: 15px; border-radius: 10px; margin-bottom: 20px; }
        .stats { display: flex; gap: 20px; margin-bottom: 20px; }
        .stat-card { background: white; padding: 20px; border-radius: 10px; text-align: center; flex: 1; }
        .stat-number { font-size: 2em; font-weight: bold; }
        .stat-number.red { color: #e74c3c; }
        .stat-number.orange { color: #f39c12; }
        .alert-card { background: #ffe5e5; border-left: 4px solid #e74c3c; padding: 15px; margin-bottom: 10px; border-radius: 5px; }
        .btn { display: inline-block; padding: 5px 10px; background: #3498db; color: white; text-decoration: none; border-radius: 5px; }
    </style>
</head>
<body>
<div class="sidebar">
    <h2>🏥 PharmaGest</h2>
    <a href="dashboard">📊 Dashboard</a>
    <a href="medicaments">💊 Médicaments</a>
    <a href="fournisseurs">🏢 Fournisseurs</a>
    <a href="alertes" class="active">⚠️ Alertes</a>
</div>
<div class="content">
    <div class="header"><h2>⚠️ Centre d'alertes</h2></div>
    
    <div class="stats">
        <div class="stat-card"><div class="stat-number red"><%= stockBas.size() %></div><div class="stat-label">Alertes rupture</div></div>
        <div class="stat-card"><div class="stat-number orange"><%= expirationCount != null ? expirationCount : 0 %></div><div class="stat-label">Expirations < 30j</div></div>
    </div>
    
    <h3>⚠️ Médicaments en rupture ou stock bas</h3>
    <% if (!stockBas.isEmpty()) { 
        for (Medicament m : stockBas) { %>
        <div class="alert-card">
            <strong>💊 <%= m.getNom() %></strong><br>
            Stock actuel : <strong><%= m.getStockActuel() %></strong> unités<br>
            Seuil critique : <%= m.getSeuilAlerte() %> unités<br>
            Fournisseur : <%= m.getFournisseurNom() %><br>
            <a href="medicaments" class="btn">📦 Réapprovisionner</a>
        </div>
    <% } } else { %>
        <p style="background: white; padding: 15px; border-radius: 10px;">✅ Aucune alerte de rupture de stock</p>
    <% } %>
</div>
</body>
</html>