<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="models.Medicament, dao.FournisseurDAO, models.Fournisseur, java.util.List" %>
<%
    Medicament m = (Medicament) request.getAttribute("medicament");
    FournisseurDAO fournisseurDAO = new FournisseurDAO();
    List<Fournisseur> fournisseurs = fournisseurDAO.getAllFournisseurs();
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Modifier médicament</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial; background: #f0f2f5; }
        .sidebar { position: fixed; left: 0; top: 0; width: 250px; height: 100%; background: #2c3e50; color: white; }
        .sidebar h2 { padding: 20px; text-align: center; }
        .sidebar a { display: block; padding: 15px 20px; color: white; text-decoration: none; }
        .sidebar a:hover { background: #34495e; }
        .content { margin-left: 250px; padding: 20px; }
        .header { background: white; padding: 15px; border-radius: 10px; margin-bottom: 20px; }
        .container { background: white; border-radius: 10px; padding: 20px; max-width: 600px; margin: 0 auto; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input, select, textarea { width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 5px; }
        .btn { padding: 10px 15px; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; display: inline-block; }
        .btn-success { background: #27ae60; color: white; }
        .btn-danger { background: #e74c3c; color: white; }
    </style>
</head>
<body>
<div class="sidebar">
    <h2>🏥 PharmaGest</h2>
    <a href="dashboard">📊 Dashboard</a>
    <a href="medicaments">💊 Médicaments</a>
    <a href="fournisseurs">🏢 Fournisseurs</a>
    <a href="alertes">⚠️ Alertes</a>
</div>
<div class="content">
    <div class="header"><h2>✏️ Modifier le médicament</h2></div>
    <div class="container">
        <form action="modifier" method="post">
            <input type="hidden" name="id" value="<%= m.getId() %>">
            <div class="form-group"><label>Code</label><input type="text" name="code" value="<%= m.getCode() %>" required></div>
            <div class="form-group"><label>Nom</label><input type="text" name="nom" value="<%= m.getNom() %>" required></div>
            <div class="form-group"><label>Description</label><textarea name="description" rows="3"><%= m.getDescription() != null ? m.getDescription() : "" %></textarea></div>
            <div class="form-group"><label>Dosage</label><input type="text" name="dosage" value="<%= m.getDosage() != null ? m.getDosage() : "" %>"></div>
            <div class="form-group">
                <label>Forme</label>
                <select name="forme">
                    <option <%= "Comprimé".equals(m.getForme()) ? "selected" : "" %>>Comprimé</option>
                    <option <%= "Gélule".equals(m.getForme()) ? "selected" : "" %>>Gélule</option>
                    <option <%= "Sirop".equals(m.getForme()) ? "selected" : "" %>>Sirop</option>
                    <option <%= "Injectable".equals(m.getForme()) ? "selected" : "" %>>Injectable</option>
                    <option <%= "Aérosol".equals(m.getForme()) ? "selected" : "" %>>Aérosol</option>
                </select>
            </div>
            <div class="form-group"><label>Prix unitaire (DH)</label><input type="number" step="0.01" name="prixUnitaire" value="<%= m.getPrixUnitaire() %>" required></div>
            <div class="form-group">
                <label>Fournisseur</label>
                <select name="fournisseurId">
                    <% for (Fournisseur f : fournisseurs) { %>
                        <option value="<%= f.getId() %>" <%= (m.getFournisseurId() == f.getId()) ? "selected" : "" %>><%= f.getNom() %></option>
                    <% } %>
                </select>
            </div>
            <div class="form-group"><label>Seuil d'alerte</label><input type="number" name="seuilAlerte" value="<%= m.getSeuilAlerte() %>"></div>
            <button type="submit" class="btn btn-success">💾 Enregistrer</button>
            <a href="medicaments" class="btn btn-danger">❌ Annuler</a>
        </form>
    </div>
</div>
</body>
</html>